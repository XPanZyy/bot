const fs = require('fs');
const chalk = require('chalk');

// Settings Bot \\
global.botname = 'XPanzBotz' //ur bot name
global.ownernumber = ['6283192276019'] 

// Settings Name \\
global.ownername = 'Revan - Official' //ur owner name
global.ownername2 = 'XPanzZyy' //ur owner name

// Settings Lainya \\
global.websitex = "https://XPanzZyy.github.io/MarketPlace"
global.wagc = "https://whatsapp.com/channel/0029VaG9VfPKWEKk1rxTQD20"
global.saluran = "120363279195205552@newsletter"
global.jidgroupnotif = '120363266755712733@g.us'
global.saluran2 = "120363335701540699@newsletter"
global.jidgroup = '120363267102694949@g.us'
global.jidch = '120363279195205552@newsletter'
global.linkch = "https://whatsapp.com/channel/0029VadFS3r89inc7Jjus03W"
global.linkgc = "https://chat.whatsapp.com/JyeT1hdCPJeLy95tzx5eyI"
global.linksosmed = "https://t.me/@XPanzZyy"
global.version = "1.0"

// Delay Jpm & Pushctc || 1000 = 1detik
global.delayJpm = 13500

// Settings Orkut
global.merchantIdOrderKuota = "-"
global.apiOrderKuota = "895965317326849802014841OKCT3A85BD1682B851EFE592AB050017DD82"
global.qrisOrderKuota = "-"

// Settings Api Digital Ocean
global.apiDigitalOcean = "-"
global.apiSimpelBot = "new2025"

// Settings All Payment
global.dana = "087811259488"
global.ovo = "Tidak Tersedia"
global.gopay = "Tidak Tersedia"

// Settings Api Panel Pterodactyl Khusus Orkut
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain = "https://rzxymodderz.privatehost.us.kg"
global.apikey = "ptla_x97jC6harPqqj4j4he70bfofjjoBxFUnL0FGw3CyYQk"
global.capikey = "ptlc_oKRPISeubyHt1KjZPKnVoeAXy7yeVBTTGHXiiyoKpqT"

// Settings Api Panel Pterodactyl Server 1
global.eggV1 = "15" // Egg ID
global.nestidV1 = "5" // nest ID
global.locV1 = "1" // Location ID
global.domainV1 = "https://-"
global.apikeyV1 = "-" //ptla
global.capikeyV1 = "-" //ptlc

// Settings Api Panel Pterodactyl Server 2
global.eggV2 = "15" // Egg ID
global.nestidV2 = "5" // nest ID
global.locV2 = "1" // Location ID
global.domainV2 = "https://-"
global.apikeyV2 = "-" //ptla
global.capikeyV2 = "-" //ptlc

// Settings Api Panel Pterodactyl Server Private Atau Server Owner
global.eggV3 = "15" // Egg ID
global.nestidV3 = "5" // nest ID
global.locV3 = "1" // Location ID
global.domainV3 = "https://-"
global.apikeyV3 = "-" //ptla
global.capikeyV3 = "-" //ptlc

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});