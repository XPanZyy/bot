const chalk = require('chalk')
const fs = require('fs')

global.allmenu = (m) => {
return`
>⏤͟͟͞͞╳── *\`[ O W N E R ]*\` ── .々─亗
> _*\`│ 䒘 ${m.prefix}broadcast\`*_
> _*\`│ 䒘 ${m.prefix}delsesi\`*_
> _*\`│ 䒘 ${m.prefix}getplugin\`*_
> _*\`│ 䒘 ${m.prefix}plugin\`*_
> _*\`│ 䒘 ${m.prefix}join\`*_
> _*\`│ 䒘 ${m.prefix}scrape\`*_
> _*\`│ 䒘 ${m.prefix}sp\`*_
> _*\`│ 䒘 ${m.prefix}self\`*_
> _*\`│ 䒘 ${m.prefix}setppbot\`*_
> _*\`│ 䒘 ${m.prefix}autoread\`*_
> _*\`│ 䒘 ${m.prefix}>\`*_
> _*\`│ 䒘 ${m.prefix}gz\`*_
> _*\`│ 䒘 ${m.prefix}$\`*_
⏤͟͟͞͞╳────────── .✦
│
>⏤͟͟͞͞╳── *\`[ D O W N L O A D E R ]\`* ── .々─亗
> _*\`│ 䒘 ${m.prefix}bstation\`*_
> _*\`│ 䒘 ${m.prefix}doodstream\`*_
> _*\`│ 䒘 ${m.prefix}facebook\`*_
> _*\`│ 䒘 ${m.prefix}instagram\`*_
> _*\`│ 䒘 ${m.prefix}pinterest\`*_
> _*\`│ 䒘 ${m.prefix}mediafire\`*_
> _*\`│ 䒘 ${m.prefix}spotify\`*_
> _*\`│ 䒘 ${m.prefix}tiktok\`*_
> _*\`│ 䒘 ${m.prefix}ttsearch\`*_
> _*\`│ 䒘 ${m.prefix}videy\`*_
> _*\`│ 䒘 ${m.prefix}ytmp3\`*_
> _*\`│ 䒘 ${m.prefix}ytmp4\`*_
> _*\`│ 䒘 ${m.prefix}splay\`*_
> _*\`│ 䒘 ${m.prefix}itunes\`*_
> _*\`│ 䒘 ${m.prefix}playap\`*_
> _*\`│ 䒘 ${m.prefix}autodownload\`*_
> _*\`│ 䒘 ${m.prefix}ringtone\`*_
> _*\`│ 䒘 ${m.prefix}pindl\`*_
> _*\`│ 䒘 ${m.prefix}gdrive\`*_
> _*\`│ 䒘 ${m.prefix}happymod\`*_
> _*\`│ 䒘 ${m.prefix}gitclone\`*_
> _*\`│ 䒘 ${m.prefix}weather\`*_
> _*\`│ 䒘 ${m.prefix}splay\`*_
> _*\`│ 䒘 ${m.prefix}gimage\`*_
> _*\`│ 䒘 ${m.prefix}google\`*_
> _*\`│ 䒘 ${m.prefix}twitter\`*_
> _*\`│ 䒘 ${m.prefix}capcut\`*_
> _*\`│ 䒘 ${m.prefix}mega\`*_
> _*\`│ 䒘 ${m.prefix}apk\`*_
⏤͟͟͞͞╳────────── .✦
│
⏤͟͟͞͞╳── *\`[ A N I M E ]\`* ── .々─亗
> _*\`│ 䒘 ${m.prefix}samehadaku\`*_
> _*\`│ 䒘 ${m.prefix}otakudesu\`*_
> _*\`│ 䒘 ${m.prefix}otakudesulatest\`*_
> _*\`│ 䒘 ${m.prefix}livechart\`*_
> _*\`│ 䒘 ${m.prefix}waifu\`*_
> _*\`│ 䒘 ${m.prefix}zerochan\`*_
> _*\`│ 䒘 ${m.prefix}kusonime\`*_
⏤͟͟͞͞╳────────── .✦
│
⏤͟͟͞͞╳── *\`[ G R O U P ]\`* ── .々─亗
> _*\`│ 䒘 ${m.prefix}demote\`*_
> _*\`│ 䒘 ${m.prefix}hidetag\`*_
> _*\`│ 䒘 ${m.prefix}totag\`*_
> _*\`│ 䒘 ${m.prefix}kick\`*_
> _*\`│ 䒘 ${m.prefix}linkgc\`*_
> _*\`│ 䒘 ${m.prefix}promote\`*_
> _*\`│ 䒘 ${m.prefix}setdesc\`*_
> _*\`│ 䒘 ${m.prefix}evoke\`*_
> _*\`│ 䒘 ${m.prefix}setnamegc\`*_
> _*\`│ 䒘 ${m.prefix}setppgc\`*_
> _*\`│ 䒘 ${m.prefix}gcsetting\`*_
⏤͟͟͞͞╳────────── .✦
│
⏤͟͟͞͞╳── *[ Search ]* ── .々─亗
> _*\`│ 䒘 ${m.prefix}wattpad\`*_
> _*\`│ 䒘 ${m.prefix}emotecraft\`*_
> _*\`│ 䒘 ${m.prefix}servermc\`*_
> _*\`│ 䒘 ${m.prefix}mc\`*_
⏤͟͟͞͞╳────────── .✦
│
⏤͟͟͞͞╳── *\`[ T O O L S ]\`* ── .々─亗
> _*\`│ 䒘 ${m.prefix}hd\`*_
> _*\`│ 䒘 ${m.prefix}remini\`*_
> _*\`│ 䒘 ${m.prefix}quoted\`*_
> _*\`│ 䒘 ${m.prefix}smeme\`*_
> _*\`│ 䒘 ${m.prefix}brat\`*_
> _*\`│ 䒘 ${m.prefix}qc\`*_
> _*\`│ 䒘 ${m.prefix}sticker\`*_
> _*\`│ 䒘 ${m.prefix}tourl\`*_
⏤͟͟͞͞╳────────── .✦
│
⏤͟͟͞͞╳── *[ Ai ]* ── .々─亗
> _*\`│ 䒘 ${m.prefix}ai\`*_
> _*\`│ 䒘 ${m.prefix}gemini\`*_
> _*\`│ 䒘 ${m.prefix}Noela\`*_
> _*\`│ 䒘 ${m.prefix}revan\`*_
⏤͟͟͞͞╳────────── .✦`}
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})