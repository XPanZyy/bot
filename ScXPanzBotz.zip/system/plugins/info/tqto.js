module.exports = {
  command: "tqto",
  alias: ["credit"],
  category: ["info"],
  description: "List Contrubutor bot ini",
  async run(m) {
    let cap = `*TERIMAKASIH KEPADA :*
    
  *\`[ Developer Script Ini ]\`*
 =>  \`Revan Official / XPanzZyy\`


  *[ Penyedia Scraper, Api, Dll ]*
 =>  Shannz
 =>  Rio
 =>  YudXml
 =>  Daffa
 
  *[ Developer Script Lainya ]*
 =>  RXHL 
 =>  PAK TZY 
 =>  ALWAYSAQIOO
 =>  DAFFADEV
 =>  DRAYXD
 =>  NANIKA
 =>  DEV² LAINYA
`;
    m.reply(cap);
  },
};
