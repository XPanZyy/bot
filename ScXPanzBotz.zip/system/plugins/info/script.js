const fs = require('node:fs')

module.exports = {
  command: "script",
  alias: ["sc", "scbot"],
  category: ["info"],
  description: "Dapatkan Script Bot Ini Hanya 25K Free Update",
  async run(m, { sock, Func }) {
  let tekssc = `⏤͟͟͞͞╳── *\`[ XPanzBotz V1.0 ]\`* ── .々─亗
> _*\`│ 䒘 sᴄʀɪᴘᴛ ᴛʏᴘᴇ : ᴄᴀsᴇ x ᴘʟᴜɢɪɴ\`*_
> _*\`│ 䒘 ʙᴀsᴇ : ʀᴇᴠᴀɴ ᴏғғɪᴄɪᴀʟ\`*_
> _*\`│ 䒘 ғɪᴛᴜʀ ᴅᴏᴡɴʟᴏᴀᴅᴇʀ\`*_
> _*\`│ 䒘 ғɪᴛᴜʀ ᴀɪ\`*_
> _*\`│ 䒘 ғɪᴛᴜʀ ᴀɪ\`*_
> _*\`│ 䒘 ғɪᴛᴜʀ ɢʀᴏᴜᴘ\`*_
> _*\`│ 䒘 ғɪᴛᴜʀ ᴛᴏᴏʟs\`*_
> _*\`│ 䒘 ғɪᴛᴜʀ ɪɴsᴛᴛᴀʟᴇʀ ᴘᴛᴇʀᴏᴅᴀᴄᴛʏʟ\`*_
> _*\`│ 䒘 ᴅʟʟ\`*_
> _*\`│ 䒘 ᴄʜᴀɴɴᴇʟ\`*_
> _*\`│ 䒘 Linkchnya\`*_
⏤͟͟͞͞╳────────── .✦`

m.reply({
  image: fs.readFileSync('./image/XPanzBotz.jpg'),
  caption: tekssc,
  contextInfo: {
    mentionedJid: [m.sender], 
      forwardingScore: 999,
       isForwarded: true,
      forwardedNewsletterMessageInfo: {
        newsletterJid: saluran,
        newsletterName: `Script By: ${ownername}`,
        serverMessageId: 143
      }
     }
   })
  },
};
