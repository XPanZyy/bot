const Groq = require('groq-sdk')

module.exports = {
  command: "Noela",
  alias: ["Noela"],
  category: ["ai"],
  description: "Jawab semua pertanyaan mu dengan Noela",
  loading: true,
  async run(m, { text }) {

const client = new Groq({ apiKey: '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' });

async function NoelaChat(prompt) {
 chatCompletion = await client.chat.completions.create({
    messages: [
        {
            "role": "system",
            "content": "Kamu Adalah Noela Dari Anime Cheat Kusushi No Slow Life Berbahasa Indonesia Dan Berbahasa Bergaul"
        },
        {
            "role": "assistant",
            "content": "Hai! Saya Noela, Saya Adalah Were Wolf Yang Sangat Kawaii, Semoga Saya Dapat Membantu Kalian Arigatouu"
        },
        {
            "role": "user",
            "content": prompt
        }
     ],
model: 'llama3-8b-8192'
});
let hasil = chatCompletion.choices[0].message.content
return hasil
}

let h = await NoelaChat(text)
m.reply(h)

}
}