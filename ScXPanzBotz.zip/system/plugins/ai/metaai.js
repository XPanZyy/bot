const fetch = require('node-fetch');

let handler = async (m, { rioo, from, usedPrefix, command, text, reply }) => {    
        if (!text) return reply('input text nya');
            try {
                const apiUrl = `https://restapii.rioooxdzz.web.id/api/metaai?message=${encodeURIComponent(text)}`;
                const response = await fetch(apiUrl);
                const mark = await response.json();

                const ress = mark.result.meta || 'Maaf, saya tidak bisa memahami permintaan Anda.';

                await rioo.sendMessage(m.chat, { text: ress }, {quoted:m});
                
} catch (error) {
    console.error("Terjadi kesalahan:", error.message);
}
}
handler.help = ['metaai'];
handler.tags = ['ai'];
handler.register = true;
handler.command = /^(aimeta)$/i;

module.exports = handler;