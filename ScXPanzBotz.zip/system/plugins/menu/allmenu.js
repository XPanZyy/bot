const moment = require("moment-timezone");
const axios = require('axios');
const fs = require("node:fs");
const path = require("node:path");
const process = require('process')
const { exec, spawn, execSync } = require('child_process');
const child_process = require('child_process')
const os = require('os')
const speed = require('performance-now')
const osu = require('node-os-utils')
const pkg = require(process.cwd() + "/package.json");

module.exports = {
    command: "allmenu",
    alias: ["menuall"],
    category: ["menu"],
    description: "Menampilkan allmenu bot",
    loading: true,
    async run(m, { sock, plugins, config, Func }) {

  const more = String.fromCharCode(8206);
  const readmore = more.repeat(4001);

let platform = os.platform()
let d = new Date(new Date + 3600000)
let locale = 'id'
let date = d.toLocaleDateString(locale, {
 day: 'numeric',
 month: 'long',
 year: 'numeric',
 timeZone: 'Asia/Jakarta'
})
let runtime = speed()
let totalreg = Object.keys(db.list().user).length

        let data = fs.readFileSync(process.cwd() + "/system/case.js", "utf8");
        let casePattern = /case\s+"([^"]+)"/g;
        let matches = data.match(casePattern);
        if (!matches) return m.reply("Tidak ada case yang ditemukan.");
        matches = matches.map(match => match.replace(/case\s+"([^"]+)"/, "$1"));

        let menu = {};
        plugins.forEach(item => {
            if (item.category && item.command) {
                item.category.forEach(cat => {
                    if (!menu[cat]) {
                        menu[cat] = { command: [] };
                    }
                    menu[cat].command.push({
                        name: item.command,
                        alias: item.alias
                    });
                });
            }
        });

        let cmd = 0, alias = 0;
        let pp = await sock.profilePictureUrl(m.sender, 'image').catch(e => 'https://files.catbox.moe/8getyg.jpg');

        Object.values(menu).forEach(category => {
            cmd += category.command.length;
            category.command.forEach(command => alias += command.alias.length);
        });

        let caption = `Halo ${m.pushName}, Aku Adalah XPanzBotz, Semoga Saya Bisa Membantu Anda Terima Kasih

⏤͟͟͞͞╳── *\`[ I N F O - U S E R ]\`* ── .々─ᯤ
> _*\`│ 䒘 ɴᴀᴍᴇ : ${m.pushName}\`*_
> _*\`│ 䒘 ɴᴏᴍᴏʀ :  ${m.sender.split('@')[0]}\`*_
> _*\`│ 䒘 ʟɪᴍɪᴛ : ${db.list().user[m.sender].limit}\`*_
⏤͟͟͞͞╳────────── .✦
│
⏤͟͟͞͞╳── *[ I N F O - B O T Z ]* ── .々─ᯤ
> _*\`│ 䒘 ɴᴀᴍᴇ : ${runtime}\`*_
> _*\`│ 䒘 ᴛʏᴘᴇ: ᴄᴀsᴇ x ᴘʟᴜɢɪɴ\`*_
> _*\`│ 䒘 ᴜsᴇʀ : ${totalreg}\`*_
> _*\`│ 䒘 ᴍᴏᴅᴇ ${${sock.public ? 'ᴘᴜʙʟɪᴄ' : `sᴇʟғ`}}\`*_
> _*\`│ 䒘 ᴘʀᴇғɪx ${m.prefix}\`*_
> _*\`│ 䒘 ᴅᴀᴛᴇ ${date}\`*_
⏤͟͟͞͞╳────────── .✦
│
⏤͟͟͞͞╳── *\`[ Menu Tambahan ]\`* ── .々─ᯤ
${matches.map((a, i) => ` ${i + 1}. *${m.prefix + a}*`).join("\n")}`;

        Object.entries(menu).forEach(([tag, commands]) => {
            caption += `\n\n⏤͟͟͞͞╳── *\`[ Menu - ${tag.toUpperCase()} ]\`* ── .々─ᯤ`;
            commands.command.forEach((command, index) => {
                caption += `\n> _*\`│ 䒘  ${command.name}\`*_`;
            });
            caption += `\n⏤͟͟͞͞╳────────── .✦`;
        });

m.reply({
  video: { url: "https://files.catbox.moe/s2t0ql.mp4" },
  caption: caption,
  gifPlayback: true,
 contextInfo: {
   mentionedJid: [m.sender],
   isForwarded: !0,
   forwardingScore: 127,
   forwardedNewsletterMessageInfo: {
   newsletterJid: saluran,
   newsletterName: `${botname} | ` + date,
   serverMessageId: -1
  },
   externalAdReply: {
   title: ` ${ownername2} 々 ${botname}`,
   body: `${ownername2} 々 ` + date,
   mediaType: 1,
   thumbnail: fs.readFileSync('./image/ftdoc.jpg'),
   sourceUrl: "https://youtube.com/@AlwaysRevan_Official/",
    }
  }
})

}
}