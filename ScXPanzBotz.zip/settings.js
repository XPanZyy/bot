const fs = require('node:fs');

const config = {
    owner: ["6283192276019","6283875773656"],
    name: "XPanzBotz",
    sessions: "sessions",
    sticker: {
      packname: "亗'XPanzZyy々Official亗",
      author: "Revan Official"
    },
   messages: {
      wait: "*( Loading )* Tunggu Sebentar...",
      owner: "*( Denied )* Kamu bukan owner ku !",
      premium: "*( Denied )* Fitur ini khusus user premium",
      group: "*( Denied )* Fitur ini khusus group",
      botAdmin: "*( Denied )* Lu siapa bukan Admin group",
      grootbotbup: "*( Denied )* Jadiin XPanzBotz admin dulu baru bisa akses",
   },
   database: "XPanzBotz-db",
   tz: "Asia/Jakarta"
}

module.exports = config

let file = require.resolve(__filename);
fs.watchFile(file, () => {
   fs.unwatchFile(file);
  delete require.cache[file];
});